NBA PLAYER DATA


```python
import pandas as pd
# Load the data into a Pandas DataFrame
df = pd.read_csv('nba.csv')
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 457 entries, 0 to 456
    Data columns (total 8 columns):
     #   Column    Non-Null Count  Dtype  
    ---  ------    --------------  -----  
     0   Name      457 non-null    object 
     1   Team      457 non-null    object 
     2   Number    457 non-null    int64  
     3   Position  457 non-null    object 
     4   Age       457 non-null    int64  
     5   Weight    457 non-null    int64  
     6   College   373 non-null    object 
     7   Salary    446 non-null    float64
    dtypes: float64(1), int64(3), object(4)
    memory usage: 28.7+ KB
    


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Team</th>
      <th>Number</th>
      <th>Position</th>
      <th>Age</th>
      <th>Weight</th>
      <th>College</th>
      <th>Salary</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Avery Bradley</td>
      <td>Boston Celtics</td>
      <td>0</td>
      <td>PG</td>
      <td>25</td>
      <td>180</td>
      <td>Texas</td>
      <td>7730337.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Jae Crowder</td>
      <td>Boston Celtics</td>
      <td>99</td>
      <td>SF</td>
      <td>25</td>
      <td>235</td>
      <td>Marquette</td>
      <td>6796117.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>John Holland</td>
      <td>Boston Celtics</td>
      <td>30</td>
      <td>SG</td>
      <td>27</td>
      <td>205</td>
      <td>Boston University</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>R.J. Hunter</td>
      <td>Boston Celtics</td>
      <td>28</td>
      <td>SG</td>
      <td>22</td>
      <td>185</td>
      <td>Georgia State</td>
      <td>1148640.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Jonas Jerebko</td>
      <td>Boston Celtics</td>
      <td>8</td>
      <td>PF</td>
      <td>29</td>
      <td>231</td>
      <td>NaN</td>
      <td>5000000.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#2. Data Cleaning:
# Handle missing values
df.dropna(inplace=True)
# Remove duplicate rows
df.drop_duplicates(inplace=True)

```


```python
# 3. Data Transformation: Create 'BMI' column using a fixed height value
# Assuming a fixed height value of 70 inches (5 feet 10 inches)
fixed_height = 70
# Create 'BMI' column
df['BMI'] = (df['Weight'] / (fixed_height ** 2)) * 703
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Team</th>
      <th>Number</th>
      <th>Position</th>
      <th>Age</th>
      <th>Weight</th>
      <th>College</th>
      <th>Salary</th>
      <th>BMI</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Avery Bradley</td>
      <td>Boston Celtics</td>
      <td>0</td>
      <td>PG</td>
      <td>25</td>
      <td>180</td>
      <td>Texas</td>
      <td>7730337.0</td>
      <td>25.824490</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Jae Crowder</td>
      <td>Boston Celtics</td>
      <td>99</td>
      <td>SF</td>
      <td>25</td>
      <td>235</td>
      <td>Marquette</td>
      <td>6796117.0</td>
      <td>33.715306</td>
    </tr>
    <tr>
      <th>3</th>
      <td>R.J. Hunter</td>
      <td>Boston Celtics</td>
      <td>28</td>
      <td>SG</td>
      <td>22</td>
      <td>185</td>
      <td>Georgia State</td>
      <td>1148640.0</td>
      <td>26.541837</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Jordan Mickey</td>
      <td>Boston Celtics</td>
      <td>55</td>
      <td>PF</td>
      <td>21</td>
      <td>235</td>
      <td>LSU</td>
      <td>1170960.0</td>
      <td>33.715306</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Kelly Olynyk</td>
      <td>Boston Celtics</td>
      <td>41</td>
      <td>C</td>
      <td>25</td>
      <td>238</td>
      <td>Gonzaga</td>
      <td>2165160.0</td>
      <td>34.145714</td>
    </tr>
  </tbody>
</table>
</div>




```python
#4. Exploratory Data Analysis (EDA):
# Summary statistics
print(df[['Age', 'Weight', 'Salary']].describe())
# Average age, weight, and salary by position
avg_by_position = df.groupby('Position')[['Age', 'Weight', 'Salary']].mean()
print(avg_by_position)
```

                  Age      Weight        Salary
    count  364.000000  364.000000  3.640000e+02
    mean    26.615385  219.785714  4.620311e+06
    std      4.233591   24.793099  5.119716e+06
    min     19.000000  161.000000  5.572200e+04
    25%     24.000000  200.000000  1.000000e+06
    50%     26.000000  220.000000  2.515440e+06
    75%     29.000000  240.000000  6.149694e+06
    max     40.000000  279.000000  2.287500e+07
                    Age      Weight        Salary
    Position                                     
    C         26.857143  252.959184  5.763867e+06
    PF        26.679012  239.456790  4.459988e+06
    PG        26.750000  190.276316  4.916069e+06
    SF        26.732394  221.746479  4.595908e+06
    SG        26.206897  206.965517  3.887058e+06
    


```python
import matplotlib.pyplot as plt
```


```python
# Histogram of player ages
plt.hist(df['Age'], bins=20)
plt.xlabel('Age')
plt.ylabel('Frequency')
plt.title('Distribution of Player Ages')
plt.show()

```


    
![png](output_7_0.png)
    



```python
# Box plot of player salaries by position
plt.figure(figsize=(12, 8))
df.boxplot(column='Salary', by='Position')
plt.ylabel('Salary')
plt.title('Box Plot of Player Salaries by Position')
plt.suptitle('')
plt.xticks(rotation=45)
plt.show()

```


    <Figure size 1200x800 with 0 Axes>



    
![png](output_8_1.png)
    



```python
# Scatter plot of 'age' vs. 'salary' by position
plt.figure(figsize=(10, 6))
colors = {'PG': 'red', 'SG': 'blue', 'SF': 'green', 'PF': 'purple', 'C': 'orange'}
plt.scatter(df['Age'], df['Salary'], c=df['Position'].map(colors), alpha=0.5)
plt.xlabel('Age')
plt.ylabel('Salary')
plt.title('Age vs. Salary by Position')
plt.legend(colors)
plt.show()
```


    
![png](output_9_0.png)
    



```python
#6. Top Players:
top_players = df.nlargest(10, 'Salary')
print(top_players)
```

                      Name                   Team  Number Position  Age  Weight  \
    33     Carmelo Anthony        New York Knicks       7       SF   32     240   
    339         Chris Bosh             Miami Heat       1       PF   32     235   
    100         Chris Paul   Los Angeles Clippers       3       PG   31     175   
    414       Kevin Durant  Oklahoma City Thunder      35       SF   27     240   
    164       Derrick Rose          Chicago Bulls       1       PG   27     190   
    349        Dwyane Wade             Miami Heat       3       SG   34     220   
    23         Brook Lopez          Brooklyn Nets      11        C   28     275   
    98      DeAndre Jordan   Los Angeles Clippers       6        C   27     265   
    174         Kevin Love    Cleveland Cavaliers       0       PF   27     251   
    294  LaMarcus Aldridge      San Antonio Spurs      12       PF   30     240   
    
              College      Salary        BMI  
    33       Syracuse  22875000.0  34.432653  
    339  Georgia Tech  22192730.0  33.715306  
    100   Wake Forest  21468695.0  25.107143  
    414         Texas  20158622.0  34.432653  
    164       Memphis  20093064.0  27.259184  
    349     Marquette  20000000.0  31.563265  
    23       Stanford  19689000.0  39.454082  
    98      Texas A&M  19689000.0  38.019388  
    174          UCLA  19689000.0  36.010816  
    294         Texas  19689000.0  34.432653  
    


```python
# 7. College Analysis:
top_colleges = df['College'].value_counts().nlargest(5)
print(top_colleges)
```

    College
    Kentucky          22
    Duke              18
    Kansas            18
    North Carolina    16
    UCLA              14
    Name: count, dtype: int64
    


```python
#8. Position Distribution:
position_counts = df['Position'].value_counts()
plt.pie(position_counts, labels=position_counts.index, autopct='%1.1f%%', startangle=140)
plt.title('Position Distribution of Players')
plt.axis('equal')
plt.show()

```


    
![png](output_12_0.png)
    



```python
#9. Team Analysis:
avg_salary_by_team = df.groupby('Team')['Salary'].mean()
print(avg_salary_by_team)
plt.figure(figsize=(10, 6))
avg_salary_by_team.plot(kind='bar')
plt.xlabel('Team')
plt.ylabel('Average Salary')
plt.title('Average Salary of Players by Team')
plt.xticks(rotation=45)
plt.show()
```

    Team
    Atlanta Hawks             5.125755e+06
    Boston Celtics            3.461756e+06
    Brooklyn Nets             3.654087e+06
    Charlotte Hornets         3.978124e+06
    Chicago Bulls             6.105483e+06
    Cleveland Cavaliers       6.733472e+06
    Dallas Mavericks          4.761692e+06
    Denver Nuggets            4.240886e+06
    Detroit Pistons           4.477884e+06
    Golden State Warriors     6.711293e+06
    Houston Rockets           4.404132e+06
    Indiana Pacers            4.004800e+06
    Los Angeles Clippers      6.707637e+06
    Los Angeles Lakers        3.270445e+06
    Memphis Grizzlies         4.374068e+06
    Miami Heat                6.583812e+06
    Milwaukee Bucks           4.771040e+06
    Minnesota Timberwolves    2.663774e+06
    New Orleans Pelicans      4.262526e+06
    New York Knicks           5.270655e+06
    Oklahoma City Thunder     5.822521e+06
    Orlando Magic             3.788729e+06
    Philadelphia 76ers        2.213778e+06
    Phoenix Suns              3.457318e+06
    Portland Trail Blazers    3.220121e+06
    Sacramento Kings          4.829760e+06
    San Antonio Spurs         5.408294e+06
    Toronto Raptors           5.737713e+06
    Utah Jazz                 5.225649e+06
    Washington Wizards        4.008557e+06
    Name: Salary, dtype: float64
    


    
![png](output_13_1.png)
    



```python
#10.Extras:
min_weight_index = df['Weight'].idxmin()
print("Index with minimum weight value:", min_weight_index)
```

    Index with minimum weight value: 152
    


```python
df_sorted = df.sort_values(by='Name', ignore_index=True)
print(df_sorted)
```

                        Name                    Team  Number Position  Age  \
    0           Aaron Brooks           Chicago Bulls       0       PG   31   
    1           Aaron Gordon           Orlando Magic       0       PF   20   
    2         Aaron Harrison       Charlotte Hornets       9       SG   21   
    3          Adreian Payne  Minnesota Timberwolves      33       PF   25   
    4             Al Horford           Atlanta Hawks      15        C   30   
    ..                   ...                     ...     ...      ...  ...   
    359  Willie Cauley-Stein        Sacramento Kings       0        C   22   
    360          Willie Reed           Brooklyn Nets      33       PF   26   
    361      Wilson Chandler          Denver Nuggets      21       SF   29   
    362          Zach LaVine  Minnesota Timberwolves       8       PG   21   
    363        Zach Randolph       Memphis Grizzlies      50       PF   34   
    
         Weight         College      Salary        BMI  
    0       161          Oregon   2250000.0  23.098571  
    1       220         Arizona   4171680.0  31.563265  
    2       210        Kentucky    525093.0  30.128571  
    3       237  Michigan State   1938840.0  34.002245  
    4       245         Florida  12000000.0  35.150000  
    ..      ...             ...         ...        ...  
    359     240        Kentucky   3398280.0  34.432653  
    360     220     Saint Louis    947276.0  31.563265  
    361     225          DePaul  10449438.0  32.280612  
    362     189            UCLA   2148360.0  27.115714  
    363     260  Michigan State   9638555.0  37.302041  
    
    [364 rows x 9 columns]
    


```python
name_series = df['Name']
print("Top 10 names:\n", name_series.head(10))
print("\nLast 10 names:\n", name_series.tail(10))

```

    Top 10 names:
     0       Avery Bradley
    1         Jae Crowder
    3         R.J. Hunter
    6       Jordan Mickey
    7        Kelly Olynyk
    8        Terry Rozier
    9        Marcus Smart
    10    Jared Sullinger
    11      Isaiah Thomas
    12        Evan Turner
    Name: Name, dtype: object
    
    Last 10 names:
     442     Trevor Booker
    443        Trey Burke
    444        Alec Burks
    446    Derrick Favors
    448    Gordon Hayward
    449       Rodney Hood
    451     Chris Johnson
    452        Trey Lyles
    453      Shelvin Mack
    456       Jeff Withey
    Name: Name, dtype: object
    


```python

```


```python

```


```python

```


```python

```


